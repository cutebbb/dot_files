package problems

import "/quux"

func baz() {}
