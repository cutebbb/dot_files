try:
    from __builtin__ import xrange as range
except:
    pass
